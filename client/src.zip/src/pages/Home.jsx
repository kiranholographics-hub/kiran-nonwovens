import { Link } from 'react-router-dom';

import Seo from '../components/Seo.jsx';
import HeroVideo from '../components/HeroVideo.jsx';
import StatsBand from '../components/StatsBand.jsx';
import SpecFinder from '../components/SpecFinder.jsx';
import BusinessAreaCard, {
  BusinessAreaGrid,
} from '../components/BusinessAreaCard.jsx';
import ProductCard, { ProductGrid } from '../components/ProductCard.jsx';
import FeatureGrid from '../components/FeatureGrid.jsx';
import { useCatalogue } from '../CatalogueContext.jsx';
import { PLANT } from '../data/catalog.js';
import { PRESENCE, SITE, isPlaceholder } from '../lib.js';
import './Home.css';

const STATS = [
  { value: PLANT.widthLabel, label: 'Roll width' },
  { value: PLANT.gsmLabel, label: 'GSM range' },
  { value: 'Needle punch', label: '+ thermal bonded' },
  { value: 'PP · PET · Viscose', label: 'Virgin, recycled, blends' },
];

/** Every point below is drawn from the plant capability and the company's
 *  product-description document — nothing is claimed that those don't say. */
const WHY = [
  {
    title: 'Made to your specification',
    text: 'GSM, thickness, width, density, fibre blend, colour and roll length are set for each order, so the material fits the product it will become.',
  },
  {
    title: 'Wide rolls, wide range',
    text: `Roll widths of ${PLANT.widthLabel} and a ${PLANT.gsmLabel} GSM range — from light linings to dense geotextiles and filter felt.`,
  },
  {
    title: 'Two processes, many fibres',
    text: 'Needle punched and thermal bonded nonwovens in polyester, PP (virgin and recycled), viscose and custom blends.',
  },
  {
    title: 'Ready for your process',
    text: 'Our fabrics cut, stitch, laminate, mould, emboss, die-cut and bond cleanly, so they move straight into your production.',
  },
];

export default function Home() {
  const presence = PRESENCE.filter((item) => !isPlaceholder(item.value));
  const { businessAreas, products, areaName } = useCatalogue();
  // One product from each of three different industries, so the section
  // shows the breadth of the range instead of three geotextiles.
  const featured = businessAreas
    .map((area) => products.find((p) => p.category === area.slug))
    .filter(Boolean)
    .slice(0, 3);

  return (
    <>
      <Seo
        title={null}
        description={SITE.description}
        path="/"
        jsonLd={{
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: SITE.name,
          url: SITE.url,
          logo: `${SITE.url}/images/brand/logo-mark.png`,
        }}
      />

      <section className="home__hero">
        <div className="split">
          <div className="split__text home__hero-text">
            <p className="home__num">01 — Introduction</p>
            <h1>Felt, formed with intent.</h1>
            <p className="lead">
              Needle punched and thermal bonded nonwovens — from geotextiles for
              civil works to acoustic felt for vehicle interiors. Made to your
              GSM, width and fibre, and built for export.
            </p>
            <div className="cta-row">
              <a href="#spec-finder" className="btn btn--fill">
                Find by specification
              </a>
              <Link to="/contact#enquiry" className="btn">
                Request a sample
              </Link>
            </div>
          </div>
          <HeroVideo
            className="home__hero-image"
            label="Close-up of needle punched nonwoven felt and a finished roll"
          />
        </div>
      </section>

      <StatsBand stats={STATS} />

      <section className="block">
        <div className="wrap">
          <p className="eyebrow">Where we work</p>
          <h2>Business Areas</h2>
          <BusinessAreaGrid>
            {businessAreas.map((area) => (
              <BusinessAreaCard key={area.slug} area={area} />
            ))}
          </BusinessAreaGrid>
        </div>
      </section>

      <section className="block block--sand" id="spec-finder">
        <div className="wrap">
          <p className="eyebrow">Find your material</p>
          <h2>Spec Finder</h2>
          <SpecFinder />
        </div>
      </section>

      <section className="block">
        <div className="wrap">
          <p className="eyebrow">Nonwoven solutions for a better tomorrow</p>
          <h2>Why Kiran Nonwovens</h2>
          <FeatureGrid items={WHY} />
        </div>
      </section>

      <section className="home__other">
        <div className="wrap home__other-inner">
          <div>
            <h2>Looking for something else?</h2>
            <p>
              If nothing here matches your exact requirement, tell us what you
              need. We develop custom material to your GSM, width, fibre and
              colour.
            </p>
          </div>
          <Link
            to="/products/industrial/customised-nonwoven-solutions"
            className="btn btn--light"
          >
            Customised solutions
          </Link>
        </div>
      </section>

      {/* Shows only the figures filled in lib.js PRESENCE; the band stays
          hidden until at least one is real, so "[X]" never reaches buyers. */}
      {presence.length ? (
        <section className="home__presence">
          <div className="wrap home__presence-row">
            {presence.map((item) => (
              <div key={item.label}>
                <b>{item.value}</b>
                <small>{item.label}</small>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      <section className="block">
        <div className="wrap">
          <div className="section-head">
            <div>
              <p className="eyebrow">A closer look</p>
              <h2>Featured materials</h2>
            </div>
            <Link to="/products" className="section-link">
              All products →
            </Link>
          </div>
          <div className="home__featured">
            <ProductGrid>
              {featured.map((product, i) => (
                <ProductCard
                  key={product.slug}
                  product={product}
                  areaName={areaName(product.category)}
                  variant={(i % 2) + 1}
                />
              ))}
            </ProductGrid>
          </div>
        </div>
      </section>
    </>
  );
}
