import { useEffect, useRef, useState } from 'react';
import { IMAGES_READY, VIDEOS_READY } from '../lib.js';
import './VideoBackdrop.css';

/**
 * A full-bleed background: looping muted video, with a poster / texture
 * fallback. Fills its positioned parent (position: absolute; inset: 0).
 *
 *  - VIDEOS_READY false  → the theme texture, slowly drifting, with a caption
 *    naming the clip that belongs there (same convention as <Media>).
 *  - VIDEOS_READY true   → <video autoplay muted loop playsinline>. If the
 *    file is missing or fails, it drops back to the poster, then the texture.
 *  - Reduced motion / data-saver → the video is not started; the poster stays.
 *  - Off-screen backdrops (eager = false) only load when they near the viewport.
 */
export default function VideoBackdrop({
  video,
  variant = 1,
  eager = false,
  className = '',
  showLabel = true,
}) {
  const ref = useRef(null);
  const [failed, setFailed] = useState(false);
  const [live, setLive] = useState(eager);

  const useVideo = VIDEOS_READY && video?.mp4 && !failed;
  const usePoster = IMAGES_READY && video?.poster;

  // Lazy-load: only attach sources when the backdrop is about to be seen.
  useEffect(() => {
    if (eager || live) return undefined;
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') {
      setLive(true);
      return undefined;
    }
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setLive(true);
          io.disconnect();
        }
      },
      { rootMargin: '300px 0px' }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [eager, live]);

  // Respect reduced-motion and data-saver: keep the poster, never autoplay.
  useEffect(() => {
    const v = ref.current?.querySelector('video');
    if (!v) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const saver = navigator.connection?.saveData;
    if (reduce || saver) {
      v.removeAttribute('autoplay');
      v.pause();
    }
  }, [useVideo, live]);

  return (
    <div ref={ref} className={`vbd ${className}`.trim()} aria-hidden="true">
      {useVideo && live ? (
        <video
          className="vbd__video"
          autoPlay
          muted
          loop
          playsInline
          preload={eager ? 'auto' : 'metadata'}
          poster={usePoster ? video.poster : undefined}
          onError={() => setFailed(true)}
        >
          {video.webm ? <source src={video.webm} type="video/webm" /> : null}
          <source src={video.mp4} type="video/mp4" />
        </video>
      ) : usePoster ? (
        <img className="vbd__video" src={video.poster} alt="" loading="lazy" />
      ) : (
        <>
          <svg
            className="vbd__texture"
            viewBox="0 0 600 500"
            preserveAspectRatio="xMidYMid slice"
            focusable="false"
          >
            <rect width="100%" height="100%" filter={`url(#nwTex${variant})`} />
          </svg>
          {showLabel && video?.label ? (
            <span className="vbd__label">{video.label} — pending</span>
          ) : null}
        </>
      )}
    </div>
  );
}
