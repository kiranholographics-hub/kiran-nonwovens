import { useEffect, useRef, useState } from 'react';
import './HeroVideo.css';

/**
 * Home-page hero film.
 *
 * Two cuts: a landscape file for desktop and a portrait file for phones.
 * The prerendered HTML ships only the poster frames (a <picture> that picks
 * the right one by screen width), so the page paints instantly and Google
 * sees a real image. After load, the browser picks ONE video file for the
 * current screen and fades it in over the poster — the other file is never
 * downloaded.
 *
 * No video at all for visitors who ask for reduced motion or data saving;
 * they keep the still poster. A pause button is always available, since the
 * film loops.
 */
const MOBILE_QUERY = '(max-width: 899px)';

const CUTS = {
  desktop: {
    src: '/videos/hero-desktop.mp4',
    poster: '/videos/hero-desktop.webp',
  },
  mobile: {
    src: '/videos/hero-mobile.mp4',
    poster: '/videos/hero-mobile.webp',
  },
};

export default function HeroVideo({ className = '', label }) {
  const videoRef = useRef(null);
  const [src, setSrc] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    const reduceMotion = window.matchMedia(
      '(prefers-reduced-motion: reduce)',
    ).matches;
    const saveData = navigator.connection?.saveData === true;
    if (reduceMotion || saveData) return undefined;

    const mq = window.matchMedia(MOBILE_QUERY);
    const pick = () => {
      setPlaying(false);
      setSrc(mq.matches ? CUTS.mobile.src : CUTS.desktop.src);
    };
    pick();
    mq.addEventListener('change', pick);
    return () => mq.removeEventListener('change', pick);
  }, []);

  const togglePause = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().catch(() => {});
      setPaused(false);
    } else {
      video.pause();
      setPaused(true);
    }
  };

  return (
    <div className={`hero-video ${className}`.trim()}>
      <picture>
        <source media={MOBILE_QUERY} srcSet={CUTS.mobile.poster} />
        <img
          className="hero-video__poster"
          src={CUTS.desktop.poster}
          alt={label}
          fetchPriority="high"
        />
      </picture>

      {src ? (
        <video
          ref={videoRef}
          key={src}
          className={`hero-video__film${playing ? ' is-playing' : ''}`}
          src={src}
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
          aria-hidden="true"
          onPlaying={() => setPlaying(true)}
        />
      ) : null}

      {src ? (
        <button
          type="button"
          className="hero-video__toggle"
          onClick={togglePause}
          aria-label={paused ? 'Play background video' : 'Pause background video'}
        >
          {paused ? (
            <svg viewBox="0 0 16 16" aria-hidden="true">
              <path d="M4 2.5v11l9-5.5z" />
            </svg>
          ) : (
            <svg viewBox="0 0 16 16" aria-hidden="true">
              <path d="M4 2.5h3v11H4zM9 2.5h3v11H9z" />
            </svg>
          )}
        </button>
      ) : null}
    </div>
  );
}
